// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Represents an owner of a package.
  static let PackageOwner = Interface(name: "PackageOwner")
}