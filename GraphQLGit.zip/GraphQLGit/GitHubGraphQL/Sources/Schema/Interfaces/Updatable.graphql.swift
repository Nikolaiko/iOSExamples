// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Entities that can be updated.
  static let Updatable = Interface(name: "Updatable")
}