// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// A subject that may be upvoted.
  static let Votable = Interface(name: "Votable")
}