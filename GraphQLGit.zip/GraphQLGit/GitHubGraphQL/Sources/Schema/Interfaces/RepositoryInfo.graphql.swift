// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// A subset of repository info.
  static let RepositoryInfo = Interface(name: "RepositoryInfo")
}