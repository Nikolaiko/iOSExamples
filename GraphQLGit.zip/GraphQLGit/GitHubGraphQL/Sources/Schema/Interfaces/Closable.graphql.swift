// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// An object that can be closed
  static let Closable = Interface(name: "Closable")
}