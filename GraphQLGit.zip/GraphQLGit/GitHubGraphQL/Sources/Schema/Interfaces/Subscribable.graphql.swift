// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Entities that can be subscribed to for web and email notifications.
  static let Subscribable = Interface(name: "Subscribable")
}