// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Represents any entity on GitHub that has a profile page.
  static let ProfileOwner = Interface(name: "ProfileOwner")
}