// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Represents an owner of a project (beta).
  static let ProjectV2Owner = Interface(name: "ProjectV2Owner")
}