// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Represents an owner of a Repository.
  static let RepositoryOwner = Interface(name: "RepositoryOwner")
}