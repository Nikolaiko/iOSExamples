// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Represents a comment.
  static let Comment = Interface(name: "Comment")
}