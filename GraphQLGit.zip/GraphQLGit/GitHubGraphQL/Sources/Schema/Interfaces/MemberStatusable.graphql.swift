// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Entities that have members who can set status messages.
  static let MemberStatusable = Interface(name: "MemberStatusable")
}