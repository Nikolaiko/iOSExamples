// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Common fields across different project field types
  static let ProjectV2FieldCommon = Interface(name: "ProjectV2FieldCommon")
}