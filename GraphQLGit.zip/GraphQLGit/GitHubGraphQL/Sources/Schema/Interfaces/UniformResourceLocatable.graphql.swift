// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Represents a type that can be retrieved by a URL.
  static let UniformResourceLocatable = Interface(name: "UniformResourceLocatable")
}