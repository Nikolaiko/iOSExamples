// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Recent projects for the owner.
  static let ProjectV2Recent = Interface(name: "ProjectV2Recent")
}