// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// An entry in the audit log.
  static let AuditEntry = Interface(name: "AuditEntry")
}