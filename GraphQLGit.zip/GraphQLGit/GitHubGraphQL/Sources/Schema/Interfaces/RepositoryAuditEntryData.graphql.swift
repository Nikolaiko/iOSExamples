// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Metadata for an audit entry with action repo.*
  static let RepositoryAuditEntryData = Interface(name: "RepositoryAuditEntryData")
}