// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Common fields across different project field value types
  static let ProjectV2ItemFieldValueCommon = Interface(name: "ProjectV2ItemFieldValueCommon")
}