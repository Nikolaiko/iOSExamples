// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Metadata for an audit entry containing enterprise account information.
  static let EnterpriseAuditEntryData = Interface(name: "EnterpriseAuditEntryData")
}