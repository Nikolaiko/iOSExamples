// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Represents an author of discussions in repositories.
  static let RepositoryDiscussionAuthor = Interface(name: "RepositoryDiscussionAuthor")
}