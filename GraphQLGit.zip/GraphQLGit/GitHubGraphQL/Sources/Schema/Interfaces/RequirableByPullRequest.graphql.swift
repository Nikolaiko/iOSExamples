// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Represents a type that can be required by a pull request for merging.
  static let RequirableByPullRequest = Interface(name: "RequirableByPullRequest")
}