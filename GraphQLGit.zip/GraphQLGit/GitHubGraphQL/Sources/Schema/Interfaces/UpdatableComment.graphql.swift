// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Comments that can be updated.
  static let UpdatableComment = Interface(name: "UpdatableComment")
}