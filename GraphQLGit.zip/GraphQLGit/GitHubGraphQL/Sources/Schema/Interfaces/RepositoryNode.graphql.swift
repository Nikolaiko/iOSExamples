// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Interfaces {
  /// Represents a object that belongs to a repository.
  static let RepositoryNode = Interface(name: "RepositoryNode")
}