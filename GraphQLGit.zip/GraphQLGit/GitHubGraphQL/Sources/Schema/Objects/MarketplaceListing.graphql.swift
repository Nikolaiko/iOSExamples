// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A listing in the GitHub integration marketplace.
  static let MarketplaceListing = Object(
    typename: "MarketplaceListing",
    implementedInterfaces: [Interfaces.Node.self]
  )
}