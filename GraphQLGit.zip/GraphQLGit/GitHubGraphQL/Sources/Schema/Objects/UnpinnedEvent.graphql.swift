// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents an 'unpinned' event on a given issue or pull request.
  static let UnpinnedEvent = Object(
    typename: "UnpinnedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}