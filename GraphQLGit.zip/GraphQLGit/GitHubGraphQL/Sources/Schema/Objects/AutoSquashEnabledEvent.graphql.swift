// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'auto_squash_enabled' event on a given pull request.
  static let AutoSquashEnabledEvent = Object(
    typename: "AutoSquashEnabledEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}