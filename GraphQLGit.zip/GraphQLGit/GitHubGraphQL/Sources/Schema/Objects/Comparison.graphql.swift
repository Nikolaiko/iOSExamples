// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a comparison between two commit revisions.
  static let Comparison = Object(
    typename: "Comparison",
    implementedInterfaces: [Interfaces.Node.self]
  )
}