// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// The connection type for User.
  static let FollowerConnection = Object(
    typename: "FollowerConnection",
    implementedInterfaces: []
  )
}