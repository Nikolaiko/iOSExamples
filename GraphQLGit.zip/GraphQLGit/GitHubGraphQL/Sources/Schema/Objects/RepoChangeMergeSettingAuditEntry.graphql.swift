// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Audit log entry for a repo.change_merge_setting event.
  static let RepoChangeMergeSettingAuditEntry = Object(
    typename: "RepoChangeMergeSettingAuditEntry",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.AuditEntry.self,
      Interfaces.RepositoryAuditEntryData.self,
      Interfaces.OrganizationAuditEntryData.self
    ]
  )
}