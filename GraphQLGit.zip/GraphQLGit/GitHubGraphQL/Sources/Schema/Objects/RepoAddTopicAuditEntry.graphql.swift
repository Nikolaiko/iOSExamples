// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Audit log entry for a repo.add_topic event.
  static let RepoAddTopicAuditEntry = Object(
    typename: "RepoAddTopicAuditEntry",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.AuditEntry.self,
      Interfaces.RepositoryAuditEntryData.self,
      Interfaces.OrganizationAuditEntryData.self,
      Interfaces.TopicAuditEntryData.self
    ]
  )
}