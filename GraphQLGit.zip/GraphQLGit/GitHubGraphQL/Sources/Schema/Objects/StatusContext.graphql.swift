// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents an individual commit status context
  static let StatusContext = Object(
    typename: "StatusContext",
    implementedInterfaces: [
      Interfaces.RequirableByPullRequest.self,
      Interfaces.Node.self
    ]
  )
}