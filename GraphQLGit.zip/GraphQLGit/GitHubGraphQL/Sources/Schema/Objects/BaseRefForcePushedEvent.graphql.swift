// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'base_ref_force_pushed' event on a given pull request.
  static let BaseRefForcePushedEvent = Object(
    typename: "BaseRefForcePushedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}