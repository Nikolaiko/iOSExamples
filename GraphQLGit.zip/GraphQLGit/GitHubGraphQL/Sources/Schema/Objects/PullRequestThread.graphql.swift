// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A threaded list of comments for a given pull request.
  static let PullRequestThread = Object(
    typename: "PullRequestThread",
    implementedInterfaces: [Interfaces.Node.self]
  )
}