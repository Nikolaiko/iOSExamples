// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'automatic_base_change_failed' event on a given pull request.
  static let AutomaticBaseChangeFailedEvent = Object(
    typename: "AutomaticBaseChangeFailedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}