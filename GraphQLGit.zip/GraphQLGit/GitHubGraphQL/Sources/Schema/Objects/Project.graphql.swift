// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Projects manage issues, pull requests and notes within a project owner.
  static let Project = Object(
    typename: "Project",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.Closable.self,
      Interfaces.Updatable.self
    ]
  )
}