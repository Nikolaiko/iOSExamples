// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Audit log entry for a org.config.disable_collaborators_only event.
  static let OrgConfigDisableCollaboratorsOnlyAuditEntry = Object(
    typename: "OrgConfigDisableCollaboratorsOnlyAuditEntry",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.AuditEntry.self,
      Interfaces.OrganizationAuditEntryData.self
    ]
  )
}