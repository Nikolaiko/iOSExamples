// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Audit log entry for a org.add_billing_manager
  static let OrgAddBillingManagerAuditEntry = Object(
    typename: "OrgAddBillingManagerAuditEntry",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.AuditEntry.self,
      Interfaces.OrganizationAuditEntryData.self
    ]
  )
}