// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A view within a ProjectV2.
  static let ProjectV2View = Object(
    typename: "ProjectV2View",
    implementedInterfaces: [Interfaces.Node.self]
  )
}