// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'milestoned' event on a given issue or pull request.
  static let MilestonedEvent = Object(
    typename: "MilestonedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}