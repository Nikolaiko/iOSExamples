// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// An iteration field inside a project.
  static let ProjectV2IterationField = Object(
    typename: "ProjectV2IterationField",
    implementedInterfaces: [
      Interfaces.ProjectV2FieldCommon.self,
      Interfaces.Node.self
    ]
  )
}