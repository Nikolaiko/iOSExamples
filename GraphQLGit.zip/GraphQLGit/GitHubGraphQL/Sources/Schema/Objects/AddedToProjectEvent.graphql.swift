// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'added_to_project' event on a given issue or pull request.
  static let AddedToProjectEvent = Object(
    typename: "AddedToProjectEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}