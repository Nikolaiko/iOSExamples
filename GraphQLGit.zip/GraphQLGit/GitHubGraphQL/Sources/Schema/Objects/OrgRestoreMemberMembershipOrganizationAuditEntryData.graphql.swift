// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Metadata for an organization membership for org.restore_member actions
  static let OrgRestoreMemberMembershipOrganizationAuditEntryData = Object(
    typename: "OrgRestoreMemberMembershipOrganizationAuditEntryData",
    implementedInterfaces: [Interfaces.OrganizationAuditEntryData.self]
  )
}