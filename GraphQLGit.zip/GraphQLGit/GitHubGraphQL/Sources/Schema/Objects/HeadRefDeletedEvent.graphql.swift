// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'head_ref_deleted' event on a given pull request.
  static let HeadRefDeletedEvent = Object(
    typename: "HeadRefDeletedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}