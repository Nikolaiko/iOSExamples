// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'auto_rebase_enabled' event on a given pull request.
  static let AutoRebaseEnabledEvent = Object(
    typename: "AutoRebaseEnabledEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}