// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A version tag contains the mapping between a tag name and a version.
  static let PackageTag = Object(
    typename: "PackageTag",
    implementedInterfaces: [Interfaces.Node.self]
  )
}