// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A GitHub Sponsors tier associated with a GitHub Sponsors listing.
  static let SponsorsTier = Object(
    typename: "SponsorsTier",
    implementedInterfaces: [Interfaces.Node.self]
  )
}