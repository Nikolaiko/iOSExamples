// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// An update sent to sponsors of a user or organization on GitHub Sponsors.
  static let SponsorshipNewsletter = Object(
    typename: "SponsorshipNewsletter",
    implementedInterfaces: [Interfaces.Node.self]
  )
}