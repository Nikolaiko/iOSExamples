// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// The queue of pull request entries to be merged into a protected branch in a repository.
  static let MergeQueue = Object(
    typename: "MergeQueue",
    implementedInterfaces: [Interfaces.Node.self]
  )
}