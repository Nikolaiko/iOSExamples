// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A Saved Reply is text a user can use to reply quickly.
  static let SavedReply = Object(
    typename: "SavedReply",
    implementedInterfaces: [Interfaces.Node.self]
  )
}