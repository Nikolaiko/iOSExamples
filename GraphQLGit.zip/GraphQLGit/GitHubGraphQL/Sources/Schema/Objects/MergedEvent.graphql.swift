// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'merged' event on a given pull request.
  static let MergedEvent = Object(
    typename: "MergedEvent",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.UniformResourceLocatable.self
    ]
  )
}