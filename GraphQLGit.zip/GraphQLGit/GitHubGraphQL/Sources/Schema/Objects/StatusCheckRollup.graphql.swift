// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents the rollup for both the check runs and status for a commit.
  static let StatusCheckRollup = Object(
    typename: "StatusCheckRollup",
    implementedInterfaces: [Interfaces.Node.self]
  )
}