// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A GitHub Enterprise Importer (GEI) repository migration.
  static let RepositoryMigration = Object(
    typename: "RepositoryMigration",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.Migration.self
    ]
  )
}