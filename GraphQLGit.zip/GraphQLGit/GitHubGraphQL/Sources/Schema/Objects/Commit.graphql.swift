// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a Git commit.
  static let Commit = Object(
    typename: "Commit",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.GitObject.self,
      Interfaces.Subscribable.self,
      Interfaces.UniformResourceLocatable.self
    ]
  )
}