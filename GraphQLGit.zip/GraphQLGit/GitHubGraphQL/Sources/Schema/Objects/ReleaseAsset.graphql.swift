// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A release asset contains the content for a release asset.
  static let ReleaseAsset = Object(
    typename: "ReleaseAsset",
    implementedInterfaces: [Interfaces.Node.self]
  )
}