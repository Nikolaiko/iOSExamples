// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a mention made by one issue or pull request to another.
  static let CrossReferencedEvent = Object(
    typename: "CrossReferencedEvent",
    implementedInterfaces: [
      Interfaces.UniformResourceLocatable.self,
      Interfaces.Node.self
    ]
  )
}