// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents an 'unlabeled' event on a given issue or pull request.
  static let UnlabeledEvent = Object(
    typename: "UnlabeledEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}