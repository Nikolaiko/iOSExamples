// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'renamed' event on a given issue or pull request
  static let RenamedTitleEvent = Object(
    typename: "RenamedTitleEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}