// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A field inside a project.
  static let ProjectV2Field = Object(
    typename: "ProjectV2Field",
    implementedInterfaces: [
      Interfaces.ProjectV2FieldCommon.self,
      Interfaces.Node.self
    ]
  )
}