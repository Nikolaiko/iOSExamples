// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A request for a user to review a pull request.
  static let ReviewRequest = Object(
    typename: "ReviewRequest",
    implementedInterfaces: [Interfaces.Node.self]
  )
}