// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'converted_to_discussion' event on a given issue.
  static let ConvertedToDiscussionEvent = Object(
    typename: "ConvertedToDiscussionEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}