// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A GitHub App.
  static let App = Object(
    typename: "App",
    implementedInterfaces: [Interfaces.Node.self]
  )
}