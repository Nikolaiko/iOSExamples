// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'ready_for_review' event on a given pull request.
  static let ReadyForReviewEvent = Object(
    typename: "ReadyForReviewEvent",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.UniformResourceLocatable.self
    ]
  )
}