// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'auto_merge_enabled' event on a given pull request.
  static let AutoMergeEnabledEvent = Object(
    typename: "AutoMergeEnabledEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}