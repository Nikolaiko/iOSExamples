// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// An item within a Project.
  static let ProjectV2Item = Object(
    typename: "ProjectV2Item",
    implementedInterfaces: [Interfaces.Node.self]
  )
}