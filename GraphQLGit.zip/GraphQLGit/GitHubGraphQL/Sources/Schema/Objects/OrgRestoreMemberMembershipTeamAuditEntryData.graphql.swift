// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Metadata for a team membership for org.restore_member actions
  static let OrgRestoreMemberMembershipTeamAuditEntryData = Object(
    typename: "OrgRestoreMemberMembershipTeamAuditEntryData",
    implementedInterfaces: [Interfaces.TeamAuditEntryData.self]
  )
}