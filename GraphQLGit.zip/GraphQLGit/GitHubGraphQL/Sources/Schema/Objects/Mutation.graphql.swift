// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// The root query for implementing GraphQL mutations.
  static let Mutation = Object(
    typename: "Mutation",
    implementedInterfaces: []
  )
}