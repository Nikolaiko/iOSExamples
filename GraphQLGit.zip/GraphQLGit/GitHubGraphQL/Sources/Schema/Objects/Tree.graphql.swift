// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a Git tree.
  static let Tree = Object(
    typename: "Tree",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.GitObject.self
    ]
  )
}