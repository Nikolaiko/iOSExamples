// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Audit log entry for a org.disable_saml event.
  static let OrgDisableSamlAuditEntry = Object(
    typename: "OrgDisableSamlAuditEntry",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.AuditEntry.self,
      Interfaces.OrganizationAuditEntryData.self
    ]
  )
}