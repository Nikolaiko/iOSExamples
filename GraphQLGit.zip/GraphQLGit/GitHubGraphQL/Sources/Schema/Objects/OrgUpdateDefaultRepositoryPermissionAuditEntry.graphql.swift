// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Audit log entry for a org.update_default_repository_permission
  static let OrgUpdateDefaultRepositoryPermissionAuditEntry = Object(
    typename: "OrgUpdateDefaultRepositoryPermissionAuditEntry",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.AuditEntry.self,
      Interfaces.OrganizationAuditEntryData.self
    ]
  )
}