// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A release contains the content for a release.
  static let Release = Object(
    typename: "Release",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.UniformResourceLocatable.self,
      Interfaces.Reactable.self
    ]
  )
}