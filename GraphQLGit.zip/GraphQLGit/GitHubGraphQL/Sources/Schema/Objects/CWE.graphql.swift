// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A common weakness enumeration
  static let CWE = Object(
    typename: "CWE",
    implementedInterfaces: [Interfaces.Node.self]
  )
}