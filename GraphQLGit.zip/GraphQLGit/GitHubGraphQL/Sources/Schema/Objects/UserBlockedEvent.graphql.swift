// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'user_blocked' event on a given user.
  static let UserBlockedEvent = Object(
    typename: "UserBlockedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}