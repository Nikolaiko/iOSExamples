// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A workflow inside a project.
  static let ProjectV2Workflow = Object(
    typename: "ProjectV2Workflow",
    implementedInterfaces: [Interfaces.Node.self]
  )
}