// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A branch protection rule.
  static let BranchProtectionRule = Object(
    typename: "BranchProtectionRule",
    implementedInterfaces: [Interfaces.Node.self]
  )
}