// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a Git reference.
  static let Ref = Object(
    typename: "Ref",
    implementedInterfaces: [Interfaces.Node.self]
  )
}