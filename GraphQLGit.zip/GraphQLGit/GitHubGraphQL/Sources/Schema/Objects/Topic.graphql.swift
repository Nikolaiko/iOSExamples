// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A topic aggregates entities that are related to a subject.
  static let Topic = Object(
    typename: "Topic",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.Starrable.self
    ]
  )
}