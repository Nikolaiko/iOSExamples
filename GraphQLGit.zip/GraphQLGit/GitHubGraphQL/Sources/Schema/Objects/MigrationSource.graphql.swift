// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A GitHub Enterprise Importer (GEI) migration source.
  static let MigrationSource = Object(
    typename: "MigrationSource",
    implementedInterfaces: [Interfaces.Node.self]
  )
}