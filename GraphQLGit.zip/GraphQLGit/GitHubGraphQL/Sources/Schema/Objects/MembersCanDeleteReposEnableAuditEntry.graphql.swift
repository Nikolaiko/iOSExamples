// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Audit log entry for a members_can_delete_repos.enable event.
  static let MembersCanDeleteReposEnableAuditEntry = Object(
    typename: "MembersCanDeleteReposEnableAuditEntry",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.AuditEntry.self,
      Interfaces.EnterpriseAuditEntryData.self,
      Interfaces.OrganizationAuditEntryData.self
    ]
  )
}