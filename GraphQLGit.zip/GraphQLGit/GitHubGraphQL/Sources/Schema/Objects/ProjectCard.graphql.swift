// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A card in a project.
  static let ProjectCard = Object(
    typename: "ProjectCard",
    implementedInterfaces: [Interfaces.Node.self]
  )
}