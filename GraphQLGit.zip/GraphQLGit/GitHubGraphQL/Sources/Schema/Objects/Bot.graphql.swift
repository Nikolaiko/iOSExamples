// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A special type of user which takes actions on behalf of GitHub Apps.
  static let Bot = Object(
    typename: "Bot",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.Actor.self,
      Interfaces.UniformResourceLocatable.self
    ]
  )
}