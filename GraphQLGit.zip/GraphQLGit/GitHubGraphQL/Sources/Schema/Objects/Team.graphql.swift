// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A team of users in an organization.
  static let Team = Object(
    typename: "Team",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.Subscribable.self,
      Interfaces.MemberStatusable.self
    ]
  )
}