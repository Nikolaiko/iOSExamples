// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Audit log entry for a members_can_delete_repos.clear event.
  static let MembersCanDeleteReposClearAuditEntry = Object(
    typename: "MembersCanDeleteReposClearAuditEntry",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.AuditEntry.self,
      Interfaces.EnterpriseAuditEntryData.self,
      Interfaces.OrganizationAuditEntryData.self
    ]
  )
}