// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// An option for a discussion poll.
  static let DiscussionPollOption = Object(
    typename: "DiscussionPollOption",
    implementedInterfaces: [Interfaces.Node.self]
  )
}