// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'automatic_base_change_succeeded' event on a given pull request.
  static let AutomaticBaseChangeSucceededEvent = Object(
    typename: "AutomaticBaseChangeSucceededEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}