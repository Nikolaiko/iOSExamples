// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A public description of a Marketplace category.
  static let MarketplaceCategory = Object(
    typename: "MarketplaceCategory",
    implementedInterfaces: [Interfaces.Node.self]
  )
}