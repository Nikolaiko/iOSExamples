// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'deployment_environment_changed' event on a given pull request.
  static let DeploymentEnvironmentChangedEvent = Object(
    typename: "DeploymentEnvironmentChangedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}