// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'convert_to_draft' event on a given pull request.
  static let ConvertToDraftEvent = Object(
    typename: "ConvertToDraftEvent",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.UniformResourceLocatable.self
    ]
  )
}