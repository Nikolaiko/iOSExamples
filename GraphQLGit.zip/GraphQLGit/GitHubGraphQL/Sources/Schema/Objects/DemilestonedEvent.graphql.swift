// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'demilestoned' event on a given issue or pull request.
  static let DemilestonedEvent = Object(
    typename: "DemilestonedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}