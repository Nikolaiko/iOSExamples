// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'pinned' event on a given issue or pull request.
  static let PinnedEvent = Object(
    typename: "PinnedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}