// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A Git push.
  static let Push = Object(
    typename: "Push",
    implementedInterfaces: [Interfaces.Node.self]
  )
}