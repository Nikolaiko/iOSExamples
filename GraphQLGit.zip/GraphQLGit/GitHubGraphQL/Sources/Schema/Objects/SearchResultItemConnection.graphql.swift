// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A list of results that matched against a search query. Regardless of the number of matches, a maximum of 1,000 results will be available across all types, potentially split across many pages.
  static let SearchResultItemConnection = Object(
    typename: "SearchResultItemConnection",
    implementedInterfaces: []
  )
}