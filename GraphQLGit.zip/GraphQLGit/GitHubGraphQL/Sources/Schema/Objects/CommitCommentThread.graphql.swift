// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A thread of comments on a commit.
  static let CommitCommentThread = Object(
    typename: "CommitCommentThread",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.RepositoryNode.self
    ]
  )
}