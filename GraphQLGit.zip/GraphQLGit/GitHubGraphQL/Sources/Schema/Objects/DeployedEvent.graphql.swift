// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'deployed' event on a given pull request.
  static let DeployedEvent = Object(
    typename: "DeployedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}