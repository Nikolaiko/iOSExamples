// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A subset of repository information queryable from an enterprise.
  static let EnterpriseRepositoryInfo = Object(
    typename: "EnterpriseRepositoryInfo",
    implementedInterfaces: [Interfaces.Node.self]
  )
}