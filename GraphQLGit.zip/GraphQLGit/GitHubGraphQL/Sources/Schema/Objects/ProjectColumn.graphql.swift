// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A column inside a project.
  static let ProjectColumn = Object(
    typename: "ProjectColumn",
    implementedInterfaces: [Interfaces.Node.self]
  )
}