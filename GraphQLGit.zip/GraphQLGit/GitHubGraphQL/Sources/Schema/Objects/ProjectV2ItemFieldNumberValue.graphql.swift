// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// The value of a number field in a Project item.
  static let ProjectV2ItemFieldNumberValue = Object(
    typename: "ProjectV2ItemFieldNumberValue",
    implementedInterfaces: [
      Interfaces.ProjectV2ItemFieldValueCommon.self,
      Interfaces.Node.self
    ]
  )
}