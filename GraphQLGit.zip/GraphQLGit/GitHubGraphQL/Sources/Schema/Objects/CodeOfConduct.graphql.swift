// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// The Code of Conduct for a repository
  static let CodeOfConduct = Object(
    typename: "CodeOfConduct",
    implementedInterfaces: [Interfaces.Node.self]
  )
}