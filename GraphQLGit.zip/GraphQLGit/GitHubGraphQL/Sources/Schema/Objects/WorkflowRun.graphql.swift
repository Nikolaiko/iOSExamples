// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A workflow run.
  static let WorkflowRun = Object(
    typename: "WorkflowRun",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.UniformResourceLocatable.self
    ]
  )
}