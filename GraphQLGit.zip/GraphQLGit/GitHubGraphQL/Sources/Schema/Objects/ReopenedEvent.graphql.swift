// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'reopened' event on any `Closable`.
  static let ReopenedEvent = Object(
    typename: "ReopenedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}