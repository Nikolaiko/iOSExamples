// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A workflow contains meta information about an Actions workflow file.
  static let Workflow = Object(
    typename: "Workflow",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.UniformResourceLocatable.self
    ]
  )
}