// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// An environment.
  static let Environment = Object(
    typename: "Environment",
    implementedInterfaces: [Interfaces.Node.self]
  )
}