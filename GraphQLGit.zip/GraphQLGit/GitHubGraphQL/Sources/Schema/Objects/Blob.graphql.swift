// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a Git blob.
  static let Blob = Object(
    typename: "Blob",
    implementedInterfaces: [
      Interfaces.GitObject.self,
      Interfaces.Node.self
    ]
  )
}