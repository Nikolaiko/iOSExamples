// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// An account to manage multiple organizations with consolidated policy and billing.
  static let Enterprise = Object(
    typename: "Enterprise",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.AnnouncementBanner.self
    ]
  )
}