// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A draft issue within a project.
  static let DraftIssue = Object(
    typename: "DraftIssue",
    implementedInterfaces: [Interfaces.Node.self]
  )
}