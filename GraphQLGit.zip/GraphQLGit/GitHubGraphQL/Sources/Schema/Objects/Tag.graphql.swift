// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a Git tag.
  static let Tag = Object(
    typename: "Tag",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.GitObject.self
    ]
  )
}