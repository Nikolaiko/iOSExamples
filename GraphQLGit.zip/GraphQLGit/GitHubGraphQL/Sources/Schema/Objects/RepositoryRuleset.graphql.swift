// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A repository ruleset.
  static let RepositoryRuleset = Object(
    typename: "RepositoryRuleset",
    implementedInterfaces: [Interfaces.Node.self]
  )
}