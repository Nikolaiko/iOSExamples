// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A category for discussions in a repository.
  static let DiscussionCategory = Object(
    typename: "DiscussionCategory",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.RepositoryNode.self
    ]
  )
}