// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// The value of an iteration field in a Project item.
  static let ProjectV2ItemFieldIterationValue = Object(
    typename: "ProjectV2ItemFieldIterationValue",
    implementedInterfaces: [
      Interfaces.ProjectV2ItemFieldValueCommon.self,
      Interfaces.Node.self
    ]
  )
}