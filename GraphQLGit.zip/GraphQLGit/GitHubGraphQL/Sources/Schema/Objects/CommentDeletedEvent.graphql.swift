// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'comment_deleted' event on a given issue or pull request.
  static let CommentDeletedEvent = Object(
    typename: "CommentDeletedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}