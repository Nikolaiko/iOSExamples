// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// An email belonging to a user account on an Enterprise Server installation.
  static let EnterpriseServerUserAccountEmail = Object(
    typename: "EnterpriseServerUserAccountEmail",
    implementedInterfaces: [Interfaces.Node.self]
  )
}