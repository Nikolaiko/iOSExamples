// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a given language found in repositories.
  static let Language = Object(
    typename: "Language",
    implementedInterfaces: [Interfaces.Node.self]
  )
}