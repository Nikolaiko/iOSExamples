// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A list of repositories owned by the subject.
  static let RepositoryConnection = Object(
    typename: "RepositoryConnection",
    implementedInterfaces: []
  )
}