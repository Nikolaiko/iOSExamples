// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A check suite.
  static let CheckSuite = Object(
    typename: "CheckSuite",
    implementedInterfaces: [Interfaces.Node.self]
  )
}