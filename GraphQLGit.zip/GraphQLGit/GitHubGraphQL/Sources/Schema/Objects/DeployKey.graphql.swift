// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A repository deploy key.
  static let DeployKey = Object(
    typename: "DeployKey",
    implementedInterfaces: [Interfaces.Node.self]
  )
}