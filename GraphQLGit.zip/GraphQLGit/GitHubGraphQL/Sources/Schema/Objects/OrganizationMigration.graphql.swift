// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A GitHub Enterprise Importer (GEI) organization migration.
  static let OrganizationMigration = Object(
    typename: "OrganizationMigration",
    implementedInterfaces: [Interfaces.Node.self]
  )
}