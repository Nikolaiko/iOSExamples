// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// An edit on user content
  static let UserContentEdit = Object(
    typename: "UserContentEdit",
    implementedInterfaces: [Interfaces.Node.self]
  )
}