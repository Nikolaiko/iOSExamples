// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'removed_from_merge_queue' event on a given pull request.
  static let RemovedFromMergeQueueEvent = Object(
    typename: "RemovedFromMergeQueueEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}