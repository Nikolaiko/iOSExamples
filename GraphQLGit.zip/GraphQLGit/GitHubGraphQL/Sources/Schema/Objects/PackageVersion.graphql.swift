// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Information about a specific package version.
  static let PackageVersion = Object(
    typename: "PackageVersion",
    implementedInterfaces: [Interfaces.Node.self]
  )
}