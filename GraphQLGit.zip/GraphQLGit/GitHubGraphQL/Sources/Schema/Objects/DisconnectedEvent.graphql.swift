// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'disconnected' event on a given issue or pull request.
  static let DisconnectedEvent = Object(
    typename: "DisconnectedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}