// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A poll for a discussion.
  static let DiscussionPoll = Object(
    typename: "DiscussionPoll",
    implementedInterfaces: [Interfaces.Node.self]
  )
}