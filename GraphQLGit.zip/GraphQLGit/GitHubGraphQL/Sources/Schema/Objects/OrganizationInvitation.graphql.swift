// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// An Invitation for a user to an organization.
  static let OrganizationInvitation = Object(
    typename: "OrganizationInvitation",
    implementedInterfaces: [Interfaces.Node.self]
  )
}