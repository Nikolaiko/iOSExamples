// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A user accounts upload from an Enterprise Server installation.
  static let EnterpriseServerUserAccountsUpload = Object(
    typename: "EnterpriseServerUserAccountsUpload",
    implementedInterfaces: [Interfaces.Node.self]
  )
}