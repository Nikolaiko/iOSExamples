// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// The connection type for Repository.
  static let StarredRepositoryConnection = Object(
    typename: "StarredRepositoryConnection",
    implementedInterfaces: []
  )
}