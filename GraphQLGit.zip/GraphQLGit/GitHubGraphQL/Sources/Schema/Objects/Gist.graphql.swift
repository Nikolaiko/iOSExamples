// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A Gist.
  static let Gist = Object(
    typename: "Gist",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.Starrable.self,
      Interfaces.UniformResourceLocatable.self
    ]
  )
}