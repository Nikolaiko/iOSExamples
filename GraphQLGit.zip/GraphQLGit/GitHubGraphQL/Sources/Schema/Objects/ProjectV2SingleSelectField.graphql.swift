// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A single select field inside a project.
  static let ProjectV2SingleSelectField = Object(
    typename: "ProjectV2SingleSelectField",
    implementedInterfaces: [
      Interfaces.ProjectV2FieldCommon.self,
      Interfaces.Node.self
    ]
  )
}