// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// An emoji reaction to a particular piece of content.
  static let Reaction = Object(
    typename: "Reaction",
    implementedInterfaces: [Interfaces.Node.self]
  )
}