// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A sponsorship relationship between a sponsor and a maintainer
  static let Sponsorship = Object(
    typename: "Sponsorship",
    implementedInterfaces: [Interfaces.Node.self]
  )
}