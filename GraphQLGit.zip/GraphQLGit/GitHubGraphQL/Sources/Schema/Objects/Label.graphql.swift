// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A label for categorizing Issues, Pull Requests, Milestones, or Discussions with a given Repository.
  static let Label = Object(
    typename: "Label",
    implementedInterfaces: [Interfaces.Node.self]
  )
}