// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A Pinned Issue is a issue pinned to a repository's index page.
  static let PinnedIssue = Object(
    typename: "PinnedIssue",
    implementedInterfaces: [Interfaces.Node.self]
  )
}