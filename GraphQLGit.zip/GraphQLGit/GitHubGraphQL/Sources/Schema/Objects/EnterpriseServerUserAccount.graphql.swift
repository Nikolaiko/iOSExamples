// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A user account on an Enterprise Server installation.
  static let EnterpriseServerUserAccount = Object(
    typename: "EnterpriseServerUserAccount",
    implementedInterfaces: [Interfaces.Node.self]
  )
}