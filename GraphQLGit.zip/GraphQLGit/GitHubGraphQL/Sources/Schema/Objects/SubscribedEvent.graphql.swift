// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'subscribed' event on a given `Subscribable`.
  static let SubscribedEvent = Object(
    typename: "SubscribedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}