// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents an 'review_requested' event on a given pull request.
  static let ReviewRequestedEvent = Object(
    typename: "ReviewRequestedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}