// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// The connection type for User.
  static let FollowingConnection = Object(
    typename: "FollowingConnection",
    implementedInterfaces: []
  )
}