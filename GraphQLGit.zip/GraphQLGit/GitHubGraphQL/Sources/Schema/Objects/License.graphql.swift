// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A repository's open source license
  static let License = Object(
    typename: "License",
    implementedInterfaces: [Interfaces.Node.self]
  )
}