// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// An event related to sponsorship activity.
  static let SponsorsActivity = Object(
    typename: "SponsorsActivity",
    implementedInterfaces: [Interfaces.Node.self]
  )
}