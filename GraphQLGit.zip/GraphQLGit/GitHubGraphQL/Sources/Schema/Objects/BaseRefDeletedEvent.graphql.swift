// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'base_ref_deleted' event on a given pull request.
  static let BaseRefDeletedEvent = Object(
    typename: "BaseRefDeletedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}