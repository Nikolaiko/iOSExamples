// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A placeholder user for attribution of imported data on GitHub.
  static let Mannequin = Object(
    typename: "Mannequin",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.Actor.self,
      Interfaces.UniformResourceLocatable.self
    ]
  )
}