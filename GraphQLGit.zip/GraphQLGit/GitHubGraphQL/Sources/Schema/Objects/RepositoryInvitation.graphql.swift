// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// An invitation for a user to be added to a repository.
  static let RepositoryInvitation = Object(
    typename: "RepositoryInvitation",
    implementedInterfaces: [Interfaces.Node.self]
  )
}