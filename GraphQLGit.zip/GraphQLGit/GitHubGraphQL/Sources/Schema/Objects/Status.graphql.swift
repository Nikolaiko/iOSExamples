// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a commit status.
  static let Status = Object(
    typename: "Status",
    implementedInterfaces: [Interfaces.Node.self]
  )
}