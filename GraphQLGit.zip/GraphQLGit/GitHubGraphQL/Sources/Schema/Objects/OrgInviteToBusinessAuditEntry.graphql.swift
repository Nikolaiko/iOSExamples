// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Audit log entry for a org.invite_to_business event.
  static let OrgInviteToBusinessAuditEntry = Object(
    typename: "OrgInviteToBusinessAuditEntry",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.AuditEntry.self,
      Interfaces.EnterpriseAuditEntryData.self,
      Interfaces.OrganizationAuditEntryData.self
    ]
  )
}