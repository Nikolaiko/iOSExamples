// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// The user's description of what they're currently doing.
  static let UserStatus = Object(
    typename: "UserStatus",
    implementedInterfaces: [Interfaces.Node.self]
  )
}