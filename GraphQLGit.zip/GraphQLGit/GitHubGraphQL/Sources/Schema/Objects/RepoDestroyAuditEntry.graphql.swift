// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Audit log entry for a repo.destroy event.
  static let RepoDestroyAuditEntry = Object(
    typename: "RepoDestroyAuditEntry",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.AuditEntry.self,
      Interfaces.RepositoryAuditEntryData.self,
      Interfaces.OrganizationAuditEntryData.self
    ]
  )
}