// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Entries in a MergeQueue
  static let MergeQueueEntry = Object(
    typename: "MergeQueueEntry",
    implementedInterfaces: [Interfaces.Node.self]
  )
}