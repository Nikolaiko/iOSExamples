// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A user's public key.
  static let PublicKey = Object(
    typename: "PublicKey",
    implementedInterfaces: [Interfaces.Node.self]
  )
}