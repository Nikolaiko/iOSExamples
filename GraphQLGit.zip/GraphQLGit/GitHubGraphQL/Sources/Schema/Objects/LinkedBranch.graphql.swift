// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A branch linked to an issue.
  static let LinkedBranch = Object(
    typename: "LinkedBranch",
    implementedInterfaces: [Interfaces.Node.self]
  )
}