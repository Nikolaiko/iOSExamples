// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A record that is promoted on a GitHub Sponsors profile.
  static let SponsorsListingFeaturedItem = Object(
    typename: "SponsorsListingFeaturedItem",
    implementedInterfaces: [Interfaces.Node.self]
  )
}