// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a commit comment thread part of a pull request.
  static let PullRequestCommitCommentThread = Object(
    typename: "PullRequestCommitCommentThread",
    implementedInterfaces: [
      Interfaces.RepositoryNode.self,
      Interfaces.Node.self
    ]
  )
}