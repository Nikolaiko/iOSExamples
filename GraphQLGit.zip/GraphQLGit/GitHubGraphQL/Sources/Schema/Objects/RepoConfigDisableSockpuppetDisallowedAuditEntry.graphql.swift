// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Audit log entry for a repo.config.disable_sockpuppet_disallowed event.
  static let RepoConfigDisableSockpuppetDisallowedAuditEntry = Object(
    typename: "RepoConfigDisableSockpuppetDisallowedAuditEntry",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.AuditEntry.self,
      Interfaces.OrganizationAuditEntryData.self,
      Interfaces.RepositoryAuditEntryData.self
    ]
  )
}