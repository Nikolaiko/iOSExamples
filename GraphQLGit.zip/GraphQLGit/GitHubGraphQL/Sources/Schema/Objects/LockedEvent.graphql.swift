// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'locked' event on a given issue or pull request.
  static let LockedEvent = Object(
    typename: "LockedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}