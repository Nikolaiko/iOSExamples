// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Information about pagination in a connection.
  static let PageInfo = Object(
    typename: "PageInfo",
    implementedInterfaces: []
  )
}