// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A file in a package version.
  static let PackageFile = Object(
    typename: "PackageFile",
    implementedInterfaces: [Interfaces.Node.self]
  )
}