// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'closed' event on any `Closable`.
  static let ClosedEvent = Object(
    typename: "ClosedEvent",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.UniformResourceLocatable.self
    ]
  )
}