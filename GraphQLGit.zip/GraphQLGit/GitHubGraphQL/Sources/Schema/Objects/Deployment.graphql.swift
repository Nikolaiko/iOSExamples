// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents triggered deployment instance.
  static let Deployment = Object(
    typename: "Deployment",
    implementedInterfaces: [Interfaces.Node.self]
  )
}