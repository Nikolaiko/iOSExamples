// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// The value of a text field in a Project item.
  static let ProjectV2ItemFieldTextValue = Object(
    typename: "ProjectV2ItemFieldTextValue",
    implementedInterfaces: [
      Interfaces.ProjectV2ItemFieldValueCommon.self,
      Interfaces.Node.self
    ]
  )
}