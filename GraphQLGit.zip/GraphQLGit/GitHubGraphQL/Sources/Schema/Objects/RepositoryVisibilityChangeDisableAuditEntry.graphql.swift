// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Audit log entry for a repository_visibility_change.disable event.
  static let RepositoryVisibilityChangeDisableAuditEntry = Object(
    typename: "RepositoryVisibilityChangeDisableAuditEntry",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.AuditEntry.self,
      Interfaces.EnterpriseAuditEntryData.self,
      Interfaces.OrganizationAuditEntryData.self
    ]
  )
}