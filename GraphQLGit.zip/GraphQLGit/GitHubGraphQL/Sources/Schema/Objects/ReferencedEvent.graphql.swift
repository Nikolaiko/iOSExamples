// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'referenced' event on a given `ReferencedSubject`.
  static let ReferencedEvent = Object(
    typename: "ReferencedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}