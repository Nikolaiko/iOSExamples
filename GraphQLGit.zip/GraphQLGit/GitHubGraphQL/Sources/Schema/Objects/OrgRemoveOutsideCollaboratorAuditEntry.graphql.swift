// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Audit log entry for a org.remove_outside_collaborator event.
  static let OrgRemoveOutsideCollaboratorAuditEntry = Object(
    typename: "OrgRemoveOutsideCollaboratorAuditEntry",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.AuditEntry.self,
      Interfaces.OrganizationAuditEntryData.self
    ]
  )
}