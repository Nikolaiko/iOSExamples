// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a 'labeled' event on a given issue or pull request.
  static let LabeledEvent = Object(
    typename: "LabeledEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}