// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents an 'added_to_merge_queue' event on a given pull request.
  static let AddedToMergeQueueEvent = Object(
    typename: "AddedToMergeQueueEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}