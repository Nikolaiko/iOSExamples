// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A Dependabot Update for a dependency in a repository
  static let DependabotUpdate = Object(
    typename: "DependabotUpdate",
    implementedInterfaces: [Interfaces.RepositoryNode.self]
  )
}