// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A team or app that has the ability to bypass a rules defined on a ruleset
  static let RepositoryRulesetBypassActor = Object(
    typename: "RepositoryRulesetBypassActor",
    implementedInterfaces: [Interfaces.Node.self]
  )
}