// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Describes the status of a given deployment attempt.
  static let DeploymentStatus = Object(
    typename: "DeploymentStatus",
    implementedInterfaces: [Interfaces.Node.self]
  )
}