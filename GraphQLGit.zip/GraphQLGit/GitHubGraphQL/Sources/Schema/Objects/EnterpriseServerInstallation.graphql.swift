// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// An Enterprise Server installation.
  static let EnterpriseServerInstallation = Object(
    typename: "EnterpriseServerInstallation",
    implementedInterfaces: [Interfaces.Node.self]
  )
}