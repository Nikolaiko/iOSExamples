// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// The query root of GitHub's GraphQL interface.
  static let Query = Object(
    typename: "Query",
    implementedInterfaces: []
  )
}