// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents a Milestone object on a given repository.
  static let Milestone = Object(
    typename: "Milestone",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.Closable.self,
      Interfaces.UniformResourceLocatable.self
    ]
  )
}