// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Represents an 'unsubscribed' event on a given `Subscribable`.
  static let UnsubscribedEvent = Object(
    typename: "UnsubscribedEvent",
    implementedInterfaces: [Interfaces.Node.self]
  )
}