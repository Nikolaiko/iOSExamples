// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Audit log entry for a oauth_application.create event.
  static let OauthApplicationCreateAuditEntry = Object(
    typename: "OauthApplicationCreateAuditEntry",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.AuditEntry.self,
      Interfaces.OauthApplicationAuditEntryData.self,
      Interfaces.OrganizationAuditEntryData.self
    ]
  )
}