// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// A check run.
  static let CheckRun = Object(
    typename: "CheckRun",
    implementedInterfaces: [
      Interfaces.Node.self,
      Interfaces.UniformResourceLocatable.self,
      Interfaces.RequirableByPullRequest.self
    ]
  )
}