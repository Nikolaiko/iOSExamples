// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// Information for an uploaded package.
  static let Package = Object(
    typename: "Package",
    implementedInterfaces: [Interfaces.Node.self]
  )
}