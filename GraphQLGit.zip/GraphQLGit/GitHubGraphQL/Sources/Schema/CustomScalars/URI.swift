// @generated
// This file was automatically generated and can be edited to
// implement advanced custom scalar functionality.
//
// Any changes to this file will not be overwritten by future
// code generation execution.

import ApolloAPI

/// An RFC 3986, RFC 3987, and RFC 6570 (level 4) compliant URI string.
public typealias URI = String
