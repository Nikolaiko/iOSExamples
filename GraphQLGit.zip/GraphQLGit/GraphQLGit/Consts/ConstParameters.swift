//
//  ConstParameters.swift
//  GraphQLGit
//
//  Created by Nikolai Baklanov on 03.05.2023.
//

import Foundation

let appUserName = "Nikolaiko"
let token = ""
