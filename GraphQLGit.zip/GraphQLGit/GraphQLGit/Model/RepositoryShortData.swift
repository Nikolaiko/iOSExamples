//
//  RepositoryShortData.swift
//  GraphQLGit
//
//  Created by Nikolai Baklanov on 03.05.2023.
//

import Foundation

struct RepositoryShortData {
    let id: String
    let name: String
}
