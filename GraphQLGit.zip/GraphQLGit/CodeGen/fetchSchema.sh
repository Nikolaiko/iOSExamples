./apollo-ios-cli fetch-schema

