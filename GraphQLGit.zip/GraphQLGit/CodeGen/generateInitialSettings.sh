./apollo-ios-cli init --schema-namespace GitHubGraphQL --module-type swiftPackageManager --overwrite

