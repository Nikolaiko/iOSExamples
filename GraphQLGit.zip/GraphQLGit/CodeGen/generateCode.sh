./apollo-ios-cli generate

